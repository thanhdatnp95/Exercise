#include <iostream>
using namespace std;

class Pet
{
protected:
    char* name;

public:
    Pet(char* aName)
    {
        name = aName;
    }

    virtual void sayHi() = 0;
};

class Fish : public Pet
{
public:
    Fish(char* aName) : Pet(aName) { }

    void sayHi()
    {
        cout << "Hello, I'm a fish. Call me " << name << endl;
    }
};

class Dog : public Pet
{
public:
    Dog(char* aName) : Pet(aName) { }

    void sayHi()
    {
        cout << "Hello, I'm a dog. Call me " << name << endl;
    }
};

//void main()
//{
//    Pet* dog = new Dog("Bob");
//    Pet* fish = new Fish("Lilla");
//
//    dog->sayHi();
//    fish->sayHi();
//
//    system("pause");
//}
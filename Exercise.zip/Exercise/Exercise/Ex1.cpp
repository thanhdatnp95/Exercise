#define _USE_MATH_DEFINES

#include <iostream>
#include <math.h>
using namespace std;

class Shape
{    
protected:
    //Side length of square/equilateral triangle or radius of circle
    double size;

public:
    Shape(double aSize)
    {
        size = aSize;
    }

    virtual double getArea() = 0;
};

class Square : public Shape
{
public:
    Square(double aSize) : Shape(aSize) { }

    double getArea()
    {
        return size * size;
    }
};

class EquTriangle : public Shape
{
public:
    EquTriangle(double aSize) : Shape(aSize) { }

    double getArea()
    {
        return size * size * (sqrt(3) / 4);
    }
};

class Circle : public Shape
{
public:
    Circle(double aSize) : Shape(aSize) { }

    double getArea()
    {
        return size * size * M_PI;
    }
};

//void main()
//{
//    Shape* square = new Square(4);
//    Shape* triangle = new EquTriangle(4);
//    Shape* circle = new Circle(4);
//
//    cout << "Area of this square is " << square->getArea() << endl;
//    cout << "Area of this triangle is " << triangle->getArea() << endl;
//    cout << "Area of this circle is " << circle->getArea() << endl;
//
//    system("pause");
//}
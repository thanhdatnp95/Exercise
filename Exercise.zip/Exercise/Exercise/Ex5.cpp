#include <iostream>
using namespace std;

template <class T>
class element
{
    T info;
    T* next;
};

template <class T>
class Stack
{
private:
    vector<T> elements;

public:
    void push(T const &);
    void pop();
    T top();
    bool empty();
};

template <class T>
void Stack<T>::push(T const &elem) {
    elements.push_back(elem);
}

template <class T>
void Stack<T>::pop() {
    if (elements.empty()) {
        throw out_of_range("Stack<>::pop(): empty stack");
    }
    else {
        elements.pop_back();
    }
}
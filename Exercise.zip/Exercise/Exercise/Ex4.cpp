#include <iostream>
using namespace std;

struct Node
{
    int data;

    Node* pNext;
    Node* pPre;
};

class DoublyLinkedList
{
    Node* pFirst;
    Node* pLast;

    int numOfItem;

public:
    DoublyLinkedList()
    {
        pFirst = NULL;
        pLast = NULL;
        numOfItem = 0;
    }

    //Get number of node
    int getNumOfItem()
    {
        return numOfItem;
    }

    //Add a node to the last position of list
    void addNode(int data)
    {
        Node* node = new Node();

        node->data = data;

        if (pFirst == NULL)
        {
            pFirst = node;
        }
        if (pLast != NULL)
        {
            pLast->pNext = node;
        }
        node->pPre = pLast;
        pLast = node;
        node->pNext = NULL;

        numOfItem++;
        cout << "Added successfully" << endl;
    }
    
    //Delete the first node matching the input data
    void deleteNode(int data)
    {
        Node* pCur = pFirst;

        while (pCur != NULL)
        {
            if (pCur->data == data)
            {
                if (pCur == pFirst)
                {
                    pFirst = pCur->pNext;
                    if (pFirst != NULL)
                        pFirst->pPre = NULL;
                    else
                        pLast = NULL;

                    delete pCur;
                    numOfItem--;
                    cout << "Deleted successfully" << endl;
                    return;
                }
                else if (pCur == pLast)
                {
                    pCur->pPre->pNext = NULL;
                    pLast = pCur->pPre;

                    delete pCur;
                    numOfItem--;
                    cout << "Deleted successfully" << endl;
                    return;
                }
                else
                {
                    pCur->pPre->pNext = pCur->pNext;
                    pCur->pNext->pPre = pCur->pPre;

                    delete pCur;
                    numOfItem--;
                    cout << "Deleted successfully" << endl;
                    return;
                }
            }
            pCur = pCur->pNext;
        }
        cout << "Nothing to delete" << endl;
    }

    //Find the node having minimum data
    void findMin()
    {
        int min;
        Node* pCur = pFirst;

        if (pCur != NULL)
        {
            min = pCur->data;
            pCur = pCur->pNext;

            while (pCur != NULL)
            {
                if (pCur->data < min)
                {
                    min = pCur->data;
                }
                pCur = pCur->pNext;
            }
            cout << "Min Value is " << min << endl;
        }            
        else
        {
            cout << "Nothing to find" << endl;
        }        
    }

    //Find the node having maximum data
    void findMax()
    {
        int max;
        Node* pCur = pFirst;

        if (pCur != NULL)
        {
            max = pCur->data;
            pCur = pCur->pNext;

            while (pCur != NULL)
            {
                if (pCur->data > max)
                {
                    max = pCur->data;
                }
                pCur = pCur->pNext;
            }
            cout << "Max Value is " << max << endl;
        }
        else
        {
            cout << "Nothing to find" << endl;
        }
    }

    //Find a matching node
    void findItem(int data)
    {
        Node* pCur = pFirst;

        if (pCur != NULL)
        {
            while (pCur != NULL)
            {
                if (pCur->data == data)
                {
                    cout << "Found a matching item" << endl;
                    return;
                }
                pCur = pCur->pNext;
            }
            cout << "Item not found" << endl;
        }
        else
        {
            cout << "Nothing to find" << endl;
        }
    }

    //Print all nodes of the list
    void printAllItem()
    {
        Node* pCur = pFirst;
        if (pCur != NULL)
        {
            cout << "List:";
            while (pCur != NULL)
            {
                cout << " " << pCur->data;
                pCur = pCur->pNext;
            }
            cout << endl;
        }
        else
        {
            cout << "Nothing to print" << endl;
        }
    }
};

//void main()
//{
//    DoublyLinkedList* list = new DoublyLinkedList();
//
//    int choice;
//    int data;
//    int exit = 0;
//
//    while (!exit)
//    {
//        cout << "========================================" << endl;
//        cout << "   Doubly Linked List Operation Menu    " << endl;
//        cout << "========================================" << endl;
//        cout << "1. Add a new item" << endl;
//        cout << "2. Delete an item" << endl;
//        cout << "3. Show number of item" << endl;
//        cout << "4. Find min item" << endl;
//        cout << "5. Find max item" << endl;
//        cout << "6. Find item" << endl;
//        cout << "7. Print all item" << endl;
//        cout << "8. Exit" << endl << endl;
//        cout << "Enter your choice: ";
//
//        cin >> choice;
//        if (choice < 1 || choice > 8)
//        {
//            cout << "Invalid choice!!!" << endl;
//        }
//        else
//        {
//            switch (choice)
//            {
//            case 1:
//                cout << "Enter data: ";
//                cin >> data;
//                list->addNode(data);
//                break;
//            case 2:
//                cout << "Enter data: ";
//                cin >> data;
//                list->deleteNode(data);
//                break;
//            case 3:
//                cout << "Num of item: " << list->getNumOfItem() << endl;
//                break;
//            case 4:
//                list->findMin();
//                break;
//            case 5:
//                list->findMax();
//                break;
//            case 6:
//                cout << "Enter data: ";
//                cin >> data;
//                list->findItem(data);
//                break;
//            case 7:
//                list->printAllItem();
//                break;
//            case 8:
//                exit = 1;
//                break;
//            default:
//                break;
//            };                
//        }
//    }
//}
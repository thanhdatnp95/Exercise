#include <iostream>
using namespace std;

class Number
{
protected:
    int value;

public:
    Number(int aValue)
    {
        value = aValue;
    }

    virtual void printIt() = 0;
};

class Hex : public Number
{
public:
    Hex(int aValue) : Number(aValue) { }

    void printIt()
    {
        printf("%X\n", value);
    }
};

class Oct : public Number
{
public:
    Oct(int aValue) : Number(aValue) { }

    void printIt()
    {
        printf("%o\n", value);
    }
};

class Dec : public Number
{
public:
    Dec(int aValue) : Number(aValue) { }

    void printIt()
    {
        printf("%d\n", value);
    }
};

//void main()
//{
//    Number* dec = new Dec(15);
//    Number* oct = new Oct(15);
//    Number* hex = new Hex(15);
//
//    dec->printIt();
//    oct->printIt();
//    hex->printIt();
//
//    system("pause");
//}